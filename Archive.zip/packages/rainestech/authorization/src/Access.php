<?php

namespace Rainestech\Authorization;

class Access {
    use Role;
}
